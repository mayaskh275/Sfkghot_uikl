
import argparse
import random
import statistics
import sys
import time
from pathlib import Path

import matplotlib.pyplot as plt


ALGORITHM_NAMES = {
    1: "Bubble Sort",
    2: "Selection Sort",
    3: "Insertion Sort",
    4: "Merge Sort",
    5: "Quick Sort",
}


def bubble_sort(arr):
    a = arr[:]
    n = len(a)
    for i in range(n):
        swapped = False
        limit = n - i - 1
        for j in range(limit):
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                swapped = True
        if not swapped:
            break
    return a


def selection_sort(arr):
    a = arr[:]
    n = len(a)
    for i in range(n):
        min_index = i
        for j in range(i + 1, n):
            if a[j] < a[min_index]:
                min_index = j
        if min_index != i:
            a[i], a[min_index] = a[min_index], a[i]
    return a


def insertion_sort(arr):
    a = arr[:]
    for i in range(1, len(a)):
        key = a[i]
        j = i - 1
        while j >= 0 and a[j] > key:
            a[j + 1] = a[j]
            j -= 1
        a[j + 1] = key
    return a


def merge_sort(arr):
    if len(arr) <= 1:
        return arr[:]

    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])

    merged = []
    i = 0
    j = 0

    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1

    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged


def _median_of_three(a, lo, hi):
    mid = (lo + hi) // 2
    x = a[lo]
    y = a[mid]
    z = a[hi]
    if x <= y <= z or z <= y <= x:
        return mid
    if y <= x <= z or z <= x <= y:
        return lo
    return hi


def quick_sort(arr):
    a = arr[:]
    if len(a) <= 1:
        return a

    stack = [(0, len(a) - 1)]

    while stack:
        lo, hi = stack.pop()
        while lo < hi:
            pivot_index = _median_of_three(a, lo, hi)
            a[pivot_index], a[hi] = a[hi], a[pivot_index]
            pivot = a[hi]

            i = lo
            for j in range(lo, hi):
                if a[j] <= pivot:
                    a[i], a[j] = a[j], a[i]
                    i += 1

            a[i], a[hi] = a[hi], a[i]

            # Process the smaller partition first to keep stack shallow
            left_size = i - lo
            right_size = hi - i
            if left_size < right_size:
                if i + 1 < hi:
                    stack.append((i + 1, hi))
                hi = i - 1
            else:
                if lo < i - 1:
                    stack.append((lo, i - 1))
                lo = i + 1

    return a


SORTING_FUNCTIONS = {
    1: bubble_sort,
    2: selection_sort,
    3: insertion_sort,
    4: merge_sort,
    5: quick_sort,
}


def generate_random_array(size, low=0, high=1_000_000):
    return [random.randint(low, high) for _ in range(size)]


def add_noise_to_sorted_array(size, noise_ratio, low=0, high=1_000_000):
    arr = sorted(generate_random_array(size, low, high))
    swaps = max(1, int(size * noise_ratio))
    for _ in range(swaps):
        i = random.randrange(size)
        j = random.randrange(size)
        arr[i], arr[j] = arr[j], arr[i]
    return arr


def measure_sort_time(sort_fn, arr):
    start = time.perf_counter()
    result = sort_fn(arr)
    end = time.perf_counter()

    if result != sorted(arr):
        raise ValueError(f"{sort_fn.__name__} did not sort correctly.")
    return end - start


def run_experiment(algorithm_ids, sizes, repetitions, experiment_type=None):
    noise_ratio = None
    title_suffix = "Random Arrays"
    output_name = "result1.png"

    if experiment_type == 1:
        noise_ratio = 0.05
        title_suffix = "Nearly Sorted Arrays (5% Noise)"
        output_name = "result2.png"
    elif experiment_type == 2:
        noise_ratio = 0.20
        title_suffix = "Nearly Sorted Arrays (20% Noise)"
        output_name = "result2.png"

    results = {
        algorithm_id: {
            "name": ALGORITHM_NAMES[algorithm_id],
            "sizes": [],
            "means": [],
            "stds": [],
        }
        for algorithm_id in algorithm_ids
    }

    for size in sizes:
        base_arrays = []
        for _ in range(repetitions):
            if noise_ratio is None:
                base_arrays.append(generate_random_array(size))
            else:
                base_arrays.append(add_noise_to_sorted_array(size, noise_ratio))

        for algorithm_id in algorithm_ids:
            sort_fn = SORTING_FUNCTIONS[algorithm_id]
            times = []

            for arr in base_arrays:
                times.append(measure_sort_time(sort_fn, arr))

            mean_time = statistics.mean(times)
            std_time = statistics.stdev(times) if len(times) > 1 else 0.0

            results[algorithm_id]["sizes"].append(size)
            results[algorithm_id]["means"].append(mean_time)
            results[algorithm_id]["stds"].append(std_time)

            print(
                f"{ALGORITHM_NAMES[algorithm_id]:<15} | "
                f"size={size:<8} | mean={mean_time:.6f}s | std={std_time:.6f}s"
            )

    create_plot(results, title_suffix, output_name)
    return results, output_name


def create_plot(results, title_suffix, output_name):
    plt.figure(figsize=(10, 6))

    for algorithm_id, data in results.items():
        x = data["sizes"]
        y = data["means"]
        yerr = data["stds"]

        plt.errorbar(
            x,
            y,
            yerr=yerr,
            marker="o",
            capsize=4,
            linewidth=2,
            label=data["name"],
        )

    plt.title(f"Runtime Comparison ({title_suffix})")
    plt.xlabel("Array size (n)")
    plt.ylabel("Runtime (seconds)")
    plt.grid(True, linestyle="--", alpha=0.6)
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_name, dpi=200)
    plt.close()


def parse_arguments():
    parser = argparse.ArgumentParser(
        description="Compare sorting algorithms on random and nearly sorted arrays."
    )
    parser.add_argument(
        "-a",
        "--algorithms",
        nargs="+",
        type=int,
        required=True,
        help="Algorithm IDs to compare: 1=Bubble, 2=Selection, 3=Insertion, 4=Merge, 5=Quick",
    )
    parser.add_argument(
        "-s",
        "--sizes",
        nargs="+",
        type=int,
        required=True,
        help="Array sizes to test, for example: 100 500 1000 3000",
    )
    parser.add_argument(
        "-e",
        "--experiment",
        type=int,
        choices=[1, 2],
        default=None,
        help="Experiment type: 1=Nearly sorted with 5%% noise, 2=Nearly sorted with 20%% noise. Omit for random arrays.",
    )
    parser.add_argument(
        "-r",
        "--repetitions",
        type=int,
        default=5,
        help="Number of repetitions per array size.",
    )
    return parser.parse_args()


def validate_arguments(args):
    if len(args.algorithms) != 3:
        raise ValueError("Please select exactly 3 algorithms using -a.")

    if len(set(args.algorithms)) != 3:
        raise ValueError("Algorithm IDs must be unique.")

    invalid = [algorithm_id for algorithm_id in args.algorithms if algorithm_id not in SORTING_FUNCTIONS]
    if invalid:
        raise ValueError(f"Invalid algorithm IDs: {invalid}")

    if any(size <= 0 for size in args.sizes):
        raise ValueError("All array sizes must be positive integers.")

    if args.repetitions <= 0:
        raise ValueError("Repetitions must be a positive integer.")


def main():
    args = parse_arguments()
    validate_arguments(args)

    run_experiment(
        algorithm_ids=args.algorithms,
        sizes=args.sizes,
        repetitions=args.repetitions,
        experiment_type=args.experiment,
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
