# Sorting Assignment

## Students
1. מיאס חואלד  
2. עבדאלרחמאן חלאילה  

## Selected Algorithms
- 3 – Insertion Sort
- 4 – Merge Sort
- 5 – Quick Sort

## Repository Structure
- `run_experiments.py` – the main Python file
- `README.md` – assignment explanation
- `result1.png` – comparison on random arrays
- `result2.png` – comparison on nearly sorted arrays

## How to Run

### Random arrays experiment
```bash
python run_experiments.py -a 3 4 5 -s 100 500 1000 3000 5000 8000 -r 5
```

### Nearly sorted arrays with 5% noise
```bash
python run_experiments.py -a 3 4 5 -s 100 500 1000 3000 5000 8000 -e 1 -r 5
```

### Nearly sorted arrays with 20% noise
```bash
python run_experiments.py -a 3 4 5 -s 100 500 1000 3000 5000 8000 -e 2 -r 5
```

## Result 1 – Random Arrays
![Result 1](result1.png)

**Explanation:**  
On random arrays, Insertion Sort is much slower as the input size grows because its average complexity is quadratic, \(O(n^2)\). Merge Sort and Quick Sort are significantly faster because their average complexity is \(O(n \log n)\). The graph clearly shows that the runtime of Insertion Sort grows much faster than the other two algorithms.

## Result 2 – Nearly Sorted Arrays
![Result 2](result2.png)

**Explanation:**  
On nearly sorted arrays, Insertion Sort becomes much faster than it was on random arrays because it performs very well when the data is already close to sorted. Merge Sort remains stable because its behavior is almost independent of the initial order. Quick Sort is also fast, but its runtime depends on the pivot strategy and the array structure. Overall, the running times changed because the degree of order in the input affects some algorithms much more than others.
